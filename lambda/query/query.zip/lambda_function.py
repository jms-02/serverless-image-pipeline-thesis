import boto3
import time
from datetime import datetime

# DB 연결 (함수 바깥에 두어 성능 최적화)
db = boto3.resource('dynamodb').Table('ImageMetadata')

def lambda_handler(event, context):
    print("Lambda 실행됨!")
    
    # S3 이벤트에서 레코드들을 가져옴
    for record in event.get('Records', []):
        try:
            # 1. 정보 추출
            bucket = record['s3']['bucket']['name']
            key = record['s3']['object']['key']
            size = record['s3']['object']['size']
            
            # 2. DynamoDB 저장 (쉼표 체크 완료!)
            db.put_item(Item={
                'image_id': key,
                'file_size_kb': size // 1024,  # 정수 나눗셈 (에러 방지)
                'status': 'success',
                'bucket_name': bucket,
                'created_at': datetime.utcnow().isoformat()
            })
            
            print(f"DB 저장 완료: {key}")
            
        except Exception as e:
            print(f"에러 발생: {str(e)}")
            
    return {'statusCode': 200}